/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int pos = 0, neg = 0, zero = 0;

        for (int i = 0; i < 10; i++) {
            int n = sc.nextInt();

            if (n > 0) {
                pos++;
            } else if (n < 0) {
                neg++;
            } else {
                zero++;
            }
        }

        System.out.println("Positivos: " + pos);
        System.out.println("Negativos: " + neg);
        System.out.println("Zeros: " + zero);

        sc.close();
    }
}