/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int soma = 0;

        for (int i = n; i >= 1; i--) {
            System.out.print(i + " ");
            soma += i;
        }

        System.out.println("\nSoma = " + soma);

        sc.close();
    }
}