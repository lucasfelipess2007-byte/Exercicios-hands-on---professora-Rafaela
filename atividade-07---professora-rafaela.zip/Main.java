/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double valor = sc.nextDouble();
        int cat = sc.nextInt();

        double desc;

        if (cat == 1) {
            desc = valor * 0.05;
        } else if (cat == 2) {
            desc = valor * 0.10;
        } else if (cat == 3) {
            desc = valor * 0.15;
        } else {
            System.out.println("Categoria inválida");
            sc.close();
            return;
        }

        double finalValor = valor - desc;

        System.out.println("Desconto: " + desc);
        System.out.println("Final: " + finalValor);

        sc.close();
    }
}